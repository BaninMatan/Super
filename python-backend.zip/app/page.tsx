"use client"

import { useState, useEffect } from "react"

export default function Page() {
  // Default to an empty string which will make requests relative to the current origin
  // This helps when the frontend is deployed but can be overridden for local development
  const API_URL =
    typeof window !== "undefined" && window.location.hostname === "localhost" ? "http://localhost:8000" : ""
  const [tasks, setTasks] = useState([])
  const [newTaskTitle, setNewTaskTitle] = useState("")
  const [randomNumber, setRandomNumber] = useState(null)
  const [loading, setLoading] = useState(false)
  const [fetchingNumber, setFetchingNumber] = useState(false)

  const fetchTasks = async () => {
    try {
      setLoading(true)
      // Add a timeout to the fetch to prevent long hanging requests
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000)

      const response = await fetch(`${API_URL}/api/tasks`, {
        signal: controller.signal,
        // Add cache: 'no-store' to prevent caching issues
        cache: "no-store",
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`)
      }

      const data = await response.json()
      setTasks(data)
    } catch (error) {
      console.error("Error fetching tasks:", error)
      // Set some default tasks when the backend is unavailable
      setTasks([
        { id: 1, title: "Example task (backend unavailable)", completed: false },
        { id: 2, title: "Connect to Python backend", completed: false },
      ])
    } finally {
      setLoading(false)
    }
  }

  const fetchRandomNumber = async () => {
    try {
      setFetchingNumber(true)
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000)

      const response = await fetch(`${API_URL}/api/random`, {
        signal: controller.signal,
        cache: "no-store",
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`)
      }

      const data = await response.json()
      setRandomNumber(data.number)
    } catch (error) {
      console.error("Error fetching random number:", error)
      // Generate a client-side random number as fallback
      setRandomNumber(Math.floor(Math.random() * 100) + 1)
    } finally {
      setFetchingNumber(false)
    }
  }

  const addTask = async () => {
    if (!newTaskTitle.trim()) return

    try {
      const newTask = {
        id: tasks.length > 0 ? Math.max(...tasks.map((t) => t.id)) + 1 : 1,
        title: newTaskTitle,
        completed: false,
      }

      // Add the task optimistically to the UI first
      setTasks([...tasks, newTask])
      setNewTaskTitle("")

      // Then try to save it to the backend
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000)

      const response = await fetch(`${API_URL}/api/tasks`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newTask),
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        console.error("Server error when adding task")
      }
    } catch (error) {
      console.error("Error adding task:", error)
      // Task is already added to UI, so we don't need to do anything else
    }
  }

  useEffect(() => {
    // Only run on the client side
    if (typeof window !== "undefined") {
      fetchTasks()
    }
  }, [])

  return (
    <main className="container mx-auto mt-8 p-4">
      <div className="max-w-4xl mx-auto mb-4">
        <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-center">
          <div className={`w-3 h-3 rounded-full mr-2 ${API_URL ? "bg-green-500" : "bg-red-500"}`}></div>
          <p className="text-sm">
            {API_URL
              ? `Connecting to Python backend at: ${API_URL}`
              : "Running in standalone mode. Python backend not configured."}
          </p>
        </div>
      </div>
      <h1 className="text-3xl font-bold mb-4">Task List</h1>

      {/* Add Task Section */}
      <div className="mb-4 flex">
        <input
          type="text"
          placeholder="Add a new task..."
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          value={newTaskTitle}
          onChange={(e) => setNewTaskTitle(e.target.value)}
        />
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded ml-2 focus:outline-none focus:shadow-outline"
          onClick={addTask}
        >
          Add Task
        </button>
      </div>

      {/* Task List Section */}
      {loading ? (
        <p>Loading tasks...</p>
      ) : (
        <ul>
          {tasks.map((task) => (
            <li key={task.id} className="mb-2 p-3 bg-white shadow rounded">
              {task.title}
            </li>
          ))}
        </ul>
      )}

      {/* Random Number Section */}
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-2">Random Number</h2>
        <button
          className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          onClick={fetchRandomNumber}
          disabled={fetchingNumber}
        >
          {fetchingNumber ? "Fetching..." : "Fetch Random Number"}
        </button>
        {randomNumber !== null && <p className="mt-2">Random Number: {randomNumber}</p>}
      </div>
    </main>
  )
}
